package com.example.trading_home

import android.net.Uri
import java.io.Serializable

class Usuario : Serializable {

    var id:String=""
    var nombre:String=""
    var email:String=""
    var password:String=""
    var direccion:String=""
    var provincia:String=""
    var imagenes= mutableListOf<String>()
    var notificaciones= mutableListOf<Notificacion>()
}