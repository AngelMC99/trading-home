package com.example.trading_home

import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.io.Serializable

class RegistroUsuario : AppCompatActivity(),Serializable {

    private lateinit var nombre:EditText
    private lateinit var email:EditText
    private lateinit var password:EditText
    private lateinit var direccion:EditText
    private lateinit var provincia:EditText
    private lateinit var btnRegistrarme:Button


    private val auth=Firebase.auth
    private val firestore=Firebase.firestore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario)

        nombre=findViewById(R.id.eTextNombre)
        email=findViewById(R.id.eTxtEmail)
        password=findViewById(R.id.eTxtPassword)
        direccion=findViewById(R.id.eTextDireccion)
        provincia=findViewById(R.id.eTextProvincia)
        btnRegistrarme=findViewById(R.id.btnRegistrarse)

        btnRegistrarme.setOnClickListener{
            var nombre=nombre.text.toString()
            var email=email.text.toString()
            var password=password.text.toString()
            var direccion=direccion.text.toString()
            var provincia=provincia.text.toString()

            val usuario=Usuario()
            usuario.nombre=nombre
            usuario.email=email
            usuario.password=password
            usuario.direccion=direccion
            usuario.provincia=provincia

            crearUsuario(usuario)
        }
    }

    override fun onBackPressed() {
    }

    fun addUsuario(usuario: Usuario){
        firestore.collection("usuarios").document(usuario.id)
            .set(usuario)
            .addOnCompleteListener { task ->
                if(task.isSuccessful){
                    Toast.makeText(this,"Exito al cargar en la BBDD",Toast.LENGTH_SHORT).show()

                    intent=Intent(this,Buscador::class.java)
                    intent.putExtra("user",usuario)
                    Log.d(TAG,usuario.id)
                    startActivity(intent)
                }
            }
            .addOnFailureListener{ e ->
                Log.w(ContentValues.TAG,"Error al cargar en la BBDD",e)
                Toast.makeText(this,"ERROR al cargar en la BBDD",Toast.LENGTH_SHORT).show()
            }
    }

    fun crearUsuario(usuario: Usuario){
        auth.createUserWithEmailAndPassword(usuario.email,usuario.password)
            .addOnCompleteListener { task ->
                if(task.isSuccessful){
                    usuario.id=auth.currentUser!!.uid
                    addUsuario(usuario)
                }
            }
            .addOnFailureListener{ e ->

                Log.w(ContentValues.TAG,"Error al crear usuario en auth",e)
                Toast.makeText(this,"Error al crear usuario", Toast.LENGTH_SHORT).show()
            }
    }
}