package com.example.trading_home

import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.view.isInvisible
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase


class ListBuscadorElementAdaptador: RecyclerView.Adapter<ListBuscadorElementAdaptador.ListBuscadorElementViewHolder>() {

    var elementos= listOf<ListBuscadorElement>()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListBuscadorElementViewHolder {
        val view=LayoutInflater
            .from(parent.context)
            .inflate(R.layout.list_buscador_element,parent,false)
        return ListBuscadorElementViewHolder(view)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onBindViewHolder(holder: ListBuscadorElementViewHolder, position: Int) {
        val elemento=elementos[position]
        holder.bind(elemento)
    }

    override fun getItemCount(): Int {
        return elementos.size
    }

    class ListBuscadorElementViewHolder(view:View) : RecyclerView.ViewHolder(view) {

        var nombre:TextView=view.findViewById(R.id.tvNombreUsuario)
        var btn:ImageButton=view.findViewById(R.id.btnMandarNotif)

        @RequiresApi(Build.VERSION_CODES.N)
        fun bind(elemento:ListBuscadorElement){
            nombre.text=elemento.nombre
            nombre.tag=elemento.idElement

            Firebase.firestore.collection("usuarios").document(nombre.tag as String)
                .get()
                .addOnCompleteListener { it ->
                    if(it.isSuccessful){
                        var doc=it.result
                        var usuario=doc.toObject<Usuario>()!!
                        var notis=usuario.notificaciones
                        if(notis.stream().map { n -> n.idUsuario }.anyMatch { id -> id.equals(Firebase.auth.currentUser!!.uid)}){
                            btn.isInvisible=true
                        }
                    }
                }

            nombre.setOnClickListener {
                val intent=Intent(nombre.context,Perfil::class.java)
                val firesore=Firebase.firestore

                firesore.collection("usuarios").document(nombre.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            var doc=task.result
                            var usuario=doc.toObject<Usuario>()!!
                            intent.putExtra("user",usuario)
                            nombre.context.startActivity(intent)
                        }
                    }
            }

            btn.setOnClickListener {
                val firestore=Firebase.firestore

                firestore.collection("usuarios").document(nombre.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            var doc=task.result
                            var usuario=doc.toObject<Usuario>()!!
                            val auth=Firebase.auth

                            if(auth.currentUser!=null){
                                var notif=Notificacion()
                                notif.idUsuario=auth.currentUser!!.uid
                                notif.tipoNotif="Nueva"
                                usuario.notificaciones.add(notif)

                                firestore.collection("usuarios").document(usuario.id)
                                    .update("notificaciones",FieldValue.arrayUnion(notif))
                                    .addOnCompleteListener { task ->
                                        if(task.isSuccessful){
                                            Toast.makeText(nombre.context,"Exito al mandar notif",Toast.LENGTH_SHORT)
                                            btn.isInvisible=true
                                        }else{
                                            Toast.makeText(nombre.context,"Error al mandar notif",Toast.LENGTH_SHORT)
                                        }
                                    }
                            }
                        }
                    }
            }
        }
    }
}