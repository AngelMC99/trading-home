package com.example.trading_home

import android.net.Uri
import android.widget.ImageView

data class ImagenElemento (val imagen:String)
