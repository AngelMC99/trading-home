package com.example.trading_home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.Serializable

class PanelNotificaciones : AppCompatActivity(),Serializable {
    private lateinit var rvNotif:RecyclerView
    private lateinit var btnAtrasNotif:ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panel_notificaciones)

        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario


        cargarDatos()
        fillRv(usuario)
        btnAtrasNotif.setOnClickListener {
            abrirBuscador(usuario)
        }
    }

    override fun onBackPressed() {
    }

    fun abrirBuscador(usuario: Usuario){
        intent=Intent(this,Buscador::class.java)
        intent.putExtra("user",usuario)
        startActivity(intent)
    }

    fun cargarDatos(){
        rvNotif=findViewById(R.id.rvNotif)
        btnAtrasNotif=findViewById(R.id.btnAtrasNotif)
    }

    fun fillRv(usuario: Usuario){

        val rvAdaptadorNotif=NotificacionElementAdaptador()
        rvNotif.adapter=rvAdaptadorNotif
        rvAdaptadorNotif.notificaciones=usuario.notificaciones
        rvNotif.layoutManager=LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()

        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario

        cargarDatos()
        fillRv(usuario)
        btnAtrasNotif.setOnClickListener {
            abrirBuscador(usuario)
        }
    }

    override fun onRestart() {
        super.onRestart()

        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario

        cargarDatos()
        fillRv(usuario)
        btnAtrasNotif.setOnClickListener {
            abrirBuscador(usuario)
        }
    }
}