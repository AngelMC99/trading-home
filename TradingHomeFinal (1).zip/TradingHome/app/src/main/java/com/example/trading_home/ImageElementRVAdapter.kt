package com.example.trading_home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ImageElementRVAdapter:RecyclerView.Adapter<ImageElementRVAdapter.ViewHolderImage>() {

    var elementos= listOf<ImagenElemento>()
        set(value){
            field=value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderImage {
        val v=LayoutInflater.from(parent.context).inflate(R.layout.image_element,parent,false)
        return ViewHolderImage(v)
    }

    override fun onBindViewHolder(holder: ImageElementRVAdapter.ViewHolderImage, position: Int) {
        val elemento=elementos[position]
        holder.bind(elemento)
    }

    override fun getItemCount(): Int {
        return elementos.size
    }

    class ViewHolderImage(view:View):RecyclerView.ViewHolder(view){

        var image:ImageView=view.findViewById(R.id.imageRV)

        fun bind(elemento:ImagenElemento){
            Glide.with(image.context).load(elemento.imagen).dontAnimate().into(image)
        }
    }
}