package com.example.trading_home

import java.io.Serializable

class ListBuscadorElement :Serializable{
    var idElement:String=""
    var nombre:String=""
}