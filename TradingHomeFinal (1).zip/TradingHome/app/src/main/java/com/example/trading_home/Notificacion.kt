package com.example.trading_home

import java.io.Serializable

class Notificacion : Serializable {

    var idUsuario:String=""
    var tipoNotif:String=""
}