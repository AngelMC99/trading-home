package com.example.trading_home

import android.content.ContentValues.TAG
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.view.isInvisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.bumptech.glide.Glide
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import java.util.*


class Perfil : AppCompatActivity() {
    private lateinit var tvNombre:TextView
    private lateinit var tvProvincia:TextView
    private lateinit var tvEmail:TextView
    private lateinit var tvDireccion:TextView
    private lateinit var btnAtras:ImageButton
    private lateinit var btnEditar:ImageButton
    private lateinit var filePath:Uri
    private lateinit var rv:RecyclerView

    private val auth=Firebase.auth
    private val firestore=Firebase.firestore
    private val storageRef=FirebaseStorage.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        tvNombre=findViewById(R.id.tvNombre)
        tvProvincia=findViewById(R.id.tvProvincia)
        tvEmail=findViewById(R.id.tvEmail)
        tvDireccion=findViewById(R.id.tvDireccion)
        btnAtras=findViewById(R.id.btnAtras)
        btnEditar=findViewById(R.id.btnEditar)
        rv=findViewById(R.id.rvPerfil)

        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario

        val loadImage=registerForActivityResult(ActivityResultContracts.GetContent(),
            ActivityResultCallback { it ->
                filePath=it
                
                val ref="Imagenes/"+UUID.randomUUID().toString()
                storageRef.getReference(ref).putFile(filePath)
                    .addOnSuccessListener {
                        Toast.makeText(this,"Subida",Toast.LENGTH_SHORT).show()
                    }.addOnFailureListener{
                        Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show()
                    }.addOnCompleteListener{
                        if(auth.currentUser!=null){
                            firestore.collection("usuarios").document(auth.currentUser!!.uid).get()
                                .addOnCompleteListener { task ->
                                    if(task.isSuccessful){
                                        val doc=task.result
                                        val usuario=doc.toObject<Usuario>()
                                        firestore.collection("usuarios").document(usuario!!.id)
                                            .update("imagenes", FieldValue.arrayUnion(filePath.toString()))
                                            .addOnSuccessListener {
                                                Toast.makeText(this,"Exito al meter nueva imagen",Toast.LENGTH_SHORT).show()

                                            }.addOnFailureListener{
                                                Toast.makeText(this,"Error al meter nueva imagen",Toast.LENGTH_SHORT).show()
                                            }.addOnCompleteListener {
                                                crearPerfil(usuario)
                                            }

                                    }
                                }
                        }
                    }
            })





        crearPerfil(usuario)

        btnAtras.setOnClickListener{
            val intent=Intent(this,Buscador::class.java)
            intent.putExtra("user",usuario)
            startActivity(intent)
        }

        btnEditar.setOnClickListener {
            Log.d(TAG,"Entrando")
            val intentGallery=Intent()
            intentGallery.type = "image/*"
            intentGallery.action=Intent.ACTION_OPEN_DOCUMENT
            intentGallery.addCategory(Intent.CATEGORY_OPENABLE)
            intentGallery.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            intentGallery.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            intentGallery.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intentGallery.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            loadImage.launch(intentGallery.type)
        }
    }

    override fun onBackPressed() {
    }

    fun crearPerfil(usuario: Usuario){
        tvNombre.text=usuario.nombre
        tvProvincia.text=usuario.provincia
        tvDireccion.text=usuario.direccion
        tvEmail.text=usuario.email
        if(usuario.id!=auth.currentUser!!.uid){
            btnEditar.isInvisible=true
        }

        val adaptadorImage=ImageElementRVAdapter()
        rv.adapter=adaptadorImage

        val listImageElementos= mutableListOf<ImagenElemento>()

        if(usuario.imagenes.isNotEmpty()){
            Log.d(TAG, "Hay imagenes")
            for(image in usuario.imagenes){
                val imagen=ImagenElemento(image)
                listImageElementos.add(imagen)
            }
        }
        rv.layoutManager=StaggeredGridLayoutManager(3,LinearLayoutManager.VERTICAL)
        adaptadorImage.elementos=listImageElementos
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG,"Resume")
        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario
        crearPerfil(usuario)
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG,"Restart")
        var usuario:Usuario=intent.getSerializableExtra("user") as Usuario
        crearPerfil(usuario)
    }
}