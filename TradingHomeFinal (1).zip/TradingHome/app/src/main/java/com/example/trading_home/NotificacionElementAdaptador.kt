package com.example.trading_home

import android.content.ContentValues.TAG
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isInvisible
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

private val NUEVA = 0
private val ACEPTADO = 1
private val MEGUSTA = 2
class NotificacionElementAdaptador : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var notificaciones= mutableListOf<Notificacion>()
        set(value) {
            field=value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if(viewType==0){
            val view = LayoutInflater.from(parent.context).inflate(R.layout.notificacion_element,parent,false)
            return NotificacionElementViewHolder(view)
        }else if(viewType==1) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.notificacion_element_aceptado,parent,false)
            return NotificacionElementAceptadoViewHolder(view)
        }else{
            val view = LayoutInflater.from(parent.context).inflate(R.layout.notificacion_element_aceptado,parent,false)
            return NotificacionElementMeGustaViewHolder(view)
        }
    }

    override fun getItemCount(): Int {

        return notificaciones.size
    }



    inner class NotificacionElementViewHolder(view: View):RecyclerView.ViewHolder(view) {

        var texto:TextView=view.findViewById(R.id.tvNotif)
        var btnMeGusta:ImageButton=view.findViewById(R.id.btnAceptarNotif)
        var btnNoMeGusta:ImageButton=view.findViewById(R.id.btnDenegarNotif)

        fun bind(notificacion:Notificacion,position: Int){

            Firebase.firestore.collection("usuarios").document(notificacion.idUsuario).get()
                .addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        val doc=task.result
                        val usuario=doc.toObject<Usuario>()
                        var nombreUsuario=usuario!!.nombre
                        texto.text= "!$nombreUsuario quiere cambiar contigo!"
                    }else{
                        Log.d(TAG,"Error en bind notificacion")
                    }
                }
            texto.tag=notificacion.idUsuario

            texto.setOnClickListener {
                val intent= Intent(texto.context,Perfil::class.java)
                val firesore= Firebase.firestore

                firesore.collection("usuarios").document(texto.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            var doc=task.result
                            var usuario=doc.toObject<Usuario>()!!
                            intent.putExtra("user",usuario)
                            texto.context.startActivity(intent)
                        }
                    }
            }
            btnMeGusta.setOnClickListener {

                Firebase.firestore.collection("usuarios").document(texto.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            val doc=task.result
                            var usuario=doc.toObject<Usuario>()!!

                            if(Firebase.auth.currentUser!=null){
                                var notif=Notificacion()
                                notif.idUsuario=Firebase.auth.currentUser!!.uid
                                notif.tipoNotif="Aceptado"
                                usuario.notificaciones.add(notif)

                                Firebase.firestore.collection("usuarios").document(usuario.id)
                                    .update("notificaciones",FieldValue.arrayUnion(notif))
                                    .addOnCompleteListener { task ->
                                        if(task.isSuccessful){
                                            Toast.makeText(texto.context,"Confirmacion enviada",Toast.LENGTH_SHORT).show()
                                            texto.text="!Confirmacion enviada a "+usuario.nombre+"!"
                                            btnMeGusta.isInvisible=true
                                            btnNoMeGusta.isInvisible=true

                                            Firebase.firestore.collection("usuarios").document(Firebase.auth.currentUser!!.uid)
                                                .update("notificaciones",FieldValue.arrayRemove(notificacion))
                                                .addOnCompleteListener { task ->
                                                    if(task.isSuccessful){
                                                        val notifMeGusta=Notificacion()
                                                        notifMeGusta.idUsuario=texto.tag as String
                                                        notifMeGusta.tipoNotif="MeGusta"
                                                        Firebase.firestore.collection("usuarios").document(Firebase.auth.currentUser!!.uid)
                                                            .update("notificaciones",FieldValue.arrayUnion(notifMeGusta))
                                                            .addOnCompleteListener { task ->
                                                                if(task.isSuccessful){
                                                                    Toast.makeText(texto.context,"Exito al mandar me gusta",Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                    }else{
                                                        Toast.makeText(texto.context,"Error con el current user",Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                        }else{
                                            Toast.makeText(texto.context,"Error al enviar confirmacion",Toast.LENGTH_SHORT).show()
                                        }
                                    }
                            }else{
                                Toast.makeText(texto.context,"No hay usuario iniciado",Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
            }
            btnNoMeGusta.setOnClickListener {
                Firebase.firestore.collection("usuarios").document(Firebase.auth.currentUser!!.uid)
                    .update("notificaciones",FieldValue.arrayRemove(notificacion))
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            Toast.makeText(texto.context,"Exito al borrar notificacion",Toast.LENGTH_SHORT).show()
                            deleteItem(position)
                        }
                    }
            }
        }
    }
    fun deleteItem(position: Int){
        notificaciones.removeAt(position)
        notifyDataSetChanged()
    }

    inner class NotificacionElementMeGustaViewHolder(view: View):RecyclerView.ViewHolder(view){

        var texto:TextView=view.findViewById(R.id.tvNotifAceptado)

        fun bind(notificacion: Notificacion,position: Int){
            Firebase.firestore.collection("usuarios").document(notificacion.idUsuario).get()
                .addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        val doc=task.result
                        val usuario=doc.toObject<Usuario>()
                        var nombreUsuario=usuario!!.nombre
                        texto.text="!Confirmacion enviada a "+usuario.nombre+"!"
                    }else{
                        Log.d(TAG,"Error al cargar notif megusta")
                    }
                }
            texto.tag=notificacion.idUsuario

            texto.setOnClickListener {
                val intent= Intent(texto.context,Perfil::class.java)
                val firesore= Firebase.firestore

                firesore.collection("usuarios").document(texto.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            var doc=task.result
                            var usuario=doc.toObject<Usuario>()!!
                            intent.putExtra("user",usuario)
                            texto.context.startActivity(intent)
                        }
                    }
            }
        }
    }

    inner class NotificacionElementAceptadoViewHolder(view:View) : RecyclerView.ViewHolder(view){

        var texto:TextView=view.findViewById(R.id.tvNotifAceptado)

        fun bind(notificacion:Notificacion,position: Int){
            Firebase.firestore.collection("usuarios").document(notificacion.idUsuario).get()
                .addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        val doc=task.result
                        val usuario=doc.toObject<Usuario>()
                        var nombreUsuario=usuario!!.nombre
                        texto.text= "!$nombreUsuario quiere cambiar contigo!"
                    }else{
                        Log.d(TAG,"Error en bind notificacion")
                    }
                }
            texto.tag=notificacion.idUsuario

            texto.setOnClickListener {
                val intent= Intent(texto.context,Perfil::class.java)
                val firesore= Firebase.firestore

                firesore.collection("usuarios").document(texto.tag as String).get()
                    .addOnCompleteListener { task ->
                        if(task.isSuccessful){
                            var doc=task.result
                            var usuario=doc.toObject<Usuario>()!!
                            intent.putExtra("user",usuario)
                            texto.context.startActivity(intent)
                        }
                    }
            }
        }
    }


    override fun getItemViewType(position: Int): Int {
        return if(notificaciones[position].tipoNotif=="Nueva"){
            NUEVA
        }else if(notificaciones[position].tipoNotif=="Aceptado"){
            ACEPTADO
        }else{
            MEGUSTA
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if(getItemViewType(position)== NUEVA){
                val notificacion=notificaciones[position]
            (holder as NotificacionElementViewHolder).bind(notificacion,position)
        }else if(getItemViewType(position)== ACEPTADO){
                val notificacion=notificaciones[position]
            (holder as NotificacionElementAceptadoViewHolder).bind(notificacion,position)
        }else{
            val notificacion=notificaciones[position]
            (holder as NotificacionElementMeGustaViewHolder).bind(notificacion,position)
        }
    }
}