package com.example.trading_home

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import java.io.Serializable

class InicioSesion : AppCompatActivity(),Serializable {

    private lateinit var btnInicio:Button
    private lateinit var eTextCorreo:EditText
    private lateinit var eTextPassword:EditText
    private lateinit var tvCuenta:TextView
    private val auth=Firebase.auth
    private val firestore=Firebase.firestore
    private var usuario=Usuario()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio_sesion)

        eTextCorreo=findViewById(R.id.eTxtEmail)
        eTextPassword=findViewById(R.id.eTxtPassword)
        btnInicio=findViewById(R.id.btnInicioSesion)
        tvCuenta=findViewById(R.id.tvCuenta)

        btnInicio.setOnClickListener{

            var email=eTextCorreo.text.toString()
            var password=eTextPassword.text.toString()

            iniciarSesion(email,password)
        }
        tvCuenta.setOnClickListener {
            intent=Intent(this,RegistroUsuario::class.java)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
    }

    fun iniciarSesion(email:String,password:String){

        auth.signInWithEmailAndPassword(email,password)
            .addOnSuccessListener {
                Toast.makeText(this,"Exito al iniciar seesion",Toast.LENGTH_SHORT)
            }
            .addOnCompleteListener { task ->
                if(task.isSuccessful){
                    firestore.collection("usuarios").document(auth.currentUser!!.uid).get()
                        .addOnSuccessListener { it ->
                            if(it.exists()){
                                usuario=it.toObject<Usuario>()!!
                            }
                        }
                        .addOnCompleteListener {
                            val intent=Intent(this,Buscador::class.java)
                            intent.putExtra("user",usuario)
                            startActivity(intent)
                        }
                }else{
                    Toast.makeText(this,"Error al iniciar seesion",Toast.LENGTH_SHORT)
                }
            }
    }
}