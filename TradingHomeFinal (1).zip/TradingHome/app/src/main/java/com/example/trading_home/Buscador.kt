package com.example.trading_home

import android.content.ContentValues.TAG
import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import java.io.Serializable

class Buscador : AppCompatActivity(),Serializable {
    private lateinit var btnPerfil:ImageButton
    private lateinit var btnNotif:ImageButton
    private lateinit var radioGroup:RadioGroup
    private lateinit var rBtnNombre:RadioButton
    private lateinit var rBtnProvincia:RadioButton
    private lateinit var rBtnDireccion:RadioButton
    private lateinit var btnBuscar:ImageButton
    private lateinit var btnSalir:ImageButton

    private lateinit var eTextBuscador:EditText
    private lateinit var rv:RecyclerView
    private val firestore=Firebase.firestore
    private val auth=Firebase.auth
    private var usuario=Usuario()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buscador)

        usuario=intent.getSerializableExtra("user") as Usuario

        cargarDatos()


        btnBuscar.setOnClickListener {
            buscarUSuarios()
        }

        btnPerfil.setOnClickListener{
           lanzarPerfilPropio()
        }

        btnNotif.setOnClickListener {
            lanzarNotificacion()
        }
        btnSalir.setOnClickListener {
            cerrarYSalir()
        }
    }

    override fun onBackPressed() {
    }

    fun cerrarYSalir(){
        if(auth.currentUser!=null) {
            auth.signOut()
            intent = Intent(this, InicioSesion::class.java)
            startActivity(intent)
        }else{
            Toast.makeText(this,"Error al salir",Toast.LENGTH_SHORT).show()
        }
    }

    fun cargarDatos(){
        btnPerfil=findViewById(R.id.btnPerfil)
        btnNotif=findViewById(R.id.btnNotif)
        radioGroup=findViewById(R.id.radioGroup)
        rBtnNombre=findViewById(R.id.rBtnNombre)
        rBtnProvincia=findViewById(R.id.rBtnProvincia)
        rBtnDireccion=findViewById(R.id.rBtnDireccion)
        btnBuscar=findViewById(R.id.btnBuscar)
        eTextBuscador=findViewById(R.id.eTextBuscador)
        rv=findViewById(R.id.rvBuscador)
        btnSalir=findViewById(R.id.btnSalir)
    }

    fun lanzarNotificacion(){
        if(auth.currentUser!=null){
            firestore.collection("usuarios").document(auth.currentUser!!.uid).get()
                .addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        val doc=task.result
                        usuario=doc.toObject<Usuario>()!!
                        intent=Intent(this,PanelNotificaciones::class.java)
                        intent.putExtra("user",usuario)
                        startActivity(intent)
                    }
                }
        }else{
            Toast.makeText(this,"No hay sesion iniciada",Toast.LENGTH_SHORT).show()
        }
    }

    fun hacerQuery(tipo:String,query:String){
        firestore.collection("usuarios").whereEqualTo(tipo,query).get()
            .addOnCompleteListener { it ->
                if(it.isSuccessful){
                    val lista= mutableListOf<ListBuscadorElement>()
                    for(doc in it.result){
                        if(doc.getString("id")as String!=auth.currentUser!!.uid){
                            var element=ListBuscadorElement()
                            element.idElement= doc.getString("id") as String
                            element.nombre=doc.getString("nombre") as String
                            lista.add(element)
                        }
                    }
                    it.result
                    val rvAdaptador = ListBuscadorElementAdaptador()
                    rv.adapter=rvAdaptador
                    rvAdaptador.elementos=lista
                    rv.layoutManager=LinearLayoutManager(this)
                }else{
                    Toast.makeText(this,"Error al buscar",Toast.LENGTH_SHORT).show()
                }
            }
    }

    fun buscarUSuarios(){

        val id=radioGroup.checkedRadioButtonId
        var query=eTextBuscador.text.toString()

        when (id) {
            rBtnNombre.id -> {
                hacerQuery("nombre",query)
            }
            rBtnProvincia.id -> {
                hacerQuery("provincia",query)
            }
            rBtnDireccion.id -> {
                hacerQuery("direccion",query)
            }
        }
    }

    fun lanzarPerfilPropio(){
        Log.d(TAG,"lanzando perfil")
        Log.d(TAG,auth.currentUser!!.uid)
        if(auth.currentUser!=null){
            firestore.collection("usuarios").document(auth.currentUser!!.uid)
                .get()
                .addOnCompleteListener { task ->
                    if(task.isSuccessful){
                        var doc=task.result
                        usuario=doc.toObject<Usuario>()!!
                        Log.d(TAG,usuario.id)
                        intent=Intent(this,Perfil::class.java)
                        intent.putExtra("user",usuario)
                        startActivity(intent)
                    }else{
                        Log.w(TAG,"Error en task")
                    }
                }.addOnFailureListener{ e ->
                    Log.w(TAG,"Error al encontrar",e)
                }
        }else{
            Log.w(TAG,"No hay perfil")
        }
    }


    override fun onResume() {
        super.onResume()
        cargarDatos()
        btnPerfil.setOnClickListener{
            lanzarPerfilPropio()
        }

        btnNotif.setOnClickListener {
            lanzarNotificacion()
        }
        btnBuscar.setOnClickListener {
            buscarUSuarios()
        }
    }

    override fun onRestart() {
        super.onRestart()
        cargarDatos()
        btnPerfil.setOnClickListener{
            lanzarPerfilPropio()
        }

        btnNotif.setOnClickListener {
            lanzarNotificacion()
        }
        btnBuscar.setOnClickListener {
            buscarUSuarios()
        }
    }
}